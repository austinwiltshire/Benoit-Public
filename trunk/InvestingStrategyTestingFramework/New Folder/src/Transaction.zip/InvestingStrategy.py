import Reccomendation
import datetime
from MyExceptions import EmptyReturns
import MarketDatabase

class InvestingStrategy(object):
    def __init__(self, market):
#        if not market:
#            market = Market.Market()
        self.market = market
        #basically undefined.  do whatever.  in basic one, might do nothing.  most
        #probably will connect to their own analyst of sorts, which might in turn connect
        #to the database or ORM.
    
    def getAdvice(self, symbol): 
        pass
    
    def __getitem__(self, symbol):
        return self.getAdvice(symbol)
    
class BasicInvestingStrategy(InvestingStrategy):
    def __init__(self, market):
        super(BasicInvestingStrategy, self).__init__(market)

    def getAdvice(self, symbol): #in design, put calender in here.  but i'm making calender global?
        #but analysts have their own connection to the database.  how are they going to get calender?
        #make calender singlton again?  or factory method with calender set?
        
        #right nwo, advice does not rely on any other calender date other than today, so this is
        #fine
        
        #returns a Reccomendation
        if symbol == self.market.getSymbol('GM') and self.market.getDate() == datetime.datetime(1,1,1):
            return Reccomendation.Buy(symbol, 1.5)
        elif symbol == self.market.getSymbol('IRBT') and self.market.getDate() == datetime.datetime(1,1,1):
            return Reccomendation.Buy(symbol, 2.0)
        elif symbol == self.market.getSymbol('GM') and self.market.getDate() == datetime.datetime(2,2,2):
            return Reccomendation.Sell(symbol, 5.0)
        elif symbol == self.market.getSymbol('IBM') and self.market.getDate() == datetime.datetime(2,2,2):
            return Reccomendation.Buy(symbol, 2.3)
        else:
            return Reccomendation.Hold(symbol, 1.0)
        
class YesterdayUp(InvestingStrategy):
    """ Gives a high buy to any stock that went up yesterday.  A high sell to any stock that went down yesterday. """
    
    def __init__(self, market):
        super(YesterdayUp, self).__init__(market)
        self.dates = self.market.getCalender().getDates()
    
    def getAdvice(self, symbol):
        #get yesterday's date
        todaysIndex = self.dates.index(self.market.getCalender().today())
        
        if todaysIndex == 0 or todaysIndex == 1:
            return Reccomendation.Hold(symbol, 5.0)
            
        
        yesterdaysDate = self.dates[todaysIndex-1]
        twodaysagoDate = self.dates[todaysIndex-2]#to judge change between prices

        
        #TODO: need to check to make sure i'm not at the begining of the dates array.
        try:
            yesterdaysPrice = self.market.getPrice(symbol, yesterdaysDate)
            twodaysagoPrice = self.market.getPrice(symbol, twodaysagoDate)
        except EmptyReturns, e: #stock is not traded yet.
            return Reccomendation.Hold(symbol, 5.0)
        except MarketDatabase.FlaggedResults, e:
            return Reccomendation.Hold(symbol, 5.0)
            
        #print yesterdaysPrice, twodaysagoPrice, symbol, yesterdaysDate
        #TODO: get rid of duplicates in your database
        if isinstance(yesterdaysPrice, list):
            yesterdaysPrice = yesterdaysPrice[0]
        if isinstance(twodaysagoPrice, list):
            twodaysagoPrice = twodaysagoPrice[0]
        #EVIL HACK
            
 #       print "Today is :", self.market.getCalender().today()
  #      print "Symbol is :", symbol
   #     print "Yesterday was : ", yesterdaysDate, " and its price was : ", yesterdaysPrice
    #    print "Two days ago was : ", twodaysagoDate, " and its price was : ", twodaysagoPrice
        
        diff = yesterdaysPrice - twodaysagoPrice
            
        if(diff > 0.0):
 #           print "Reccomending buy"
            return Reccomendation.Buy(symbol, 5.0)
        elif(diff == 0.0):
 #           print "Reccomending hold"
            return Reccomendation.Buy(symbol, 5.0)
        elif(diff < 0.0):
 #           print "Reccomending sell"
            return Reccomendation.Sell(symbol, 5.0)
